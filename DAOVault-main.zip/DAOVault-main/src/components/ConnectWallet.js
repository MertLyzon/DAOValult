import React, { useState } from 'react';
import Web3 from 'web3';
import { useNavigate } from 'react-router-dom'; // Yönlendirme için

const ConnectWallet = () => {
    const [account, setAccount] = useState(null);
    const [error, setError] = useState(null);
    const navigate = useNavigate(); // Yönlendirme hook'u

    const connectWallet = async () => {
        if (window.ethereum) {
            try {
                const web3 = new Web3(window.ethereum);
                const accounts = await web3.eth.requestAccounts();
                setAccount(accounts[0]);
                setError(null);

                // Bağlantı sağlandıktan sonra yönlendir
                navigate('/scroll'); // Scroll ağı sayfasının yolu
            } catch (error) {
                console.error("Error connecting to MetaMask:", error);
                setError("Failed to connect to MetaMask.");
            }
        } else {
            setError("MetaMask is not installed. Please install MetaMask and try again.");
        }
    };

    return (
        <div>
            {account ? (
                <p>Connected: {account}</p>
            ) : (
                <>
                    <button onClick={connectWallet}>Connect to Wallet</button>
                    {error && <p style={{ color: 'red' }}>{error}</p>}
                </>
            )}
        </div>
    );
};

export default ConnectWallet;
